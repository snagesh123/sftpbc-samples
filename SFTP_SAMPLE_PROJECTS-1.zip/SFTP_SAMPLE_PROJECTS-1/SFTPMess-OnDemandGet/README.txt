This project does the following
1) Pick files from SFTP directory MesRepOnDemandGet/inbox that match the file pattern myfileitem%u where %u is UUID format
2) Archives the processed file to MesRepOnDemandGet/inarchive directory
3) Eventually writes the file to E:\temp\outputfile directory using the fileName pattern as output%u.xml where %u represent an UUID format