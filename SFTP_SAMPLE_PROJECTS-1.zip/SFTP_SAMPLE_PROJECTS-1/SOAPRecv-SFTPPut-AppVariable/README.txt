This project uses the App variable.

Following attributes are configured using App Variables
1) sftp:address->url
2) sftp:address->privatekey
3) sftp:address->passphrase
4) sftp:transfer->localFileLocation

The project connects to remote SFTP server and writes the file content read from the file located under localFileLocation to sendToDir/targetfile.txt 